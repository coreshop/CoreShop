
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopnotification = "/bundles/coreshopnotification/studio/72a5f7faa471a0a34b7d497ade9e0a53/static/js/remoteEntry.js"

      
    