
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopnotification = "/bundles/coreshopnotification/studio/4ea5904cea2308643f786deeb6c1e8bc/static/js/remoteEntry.js"

      
    