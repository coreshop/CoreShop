
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopnotification = "/bundles/coreshopnotification/studio/31addeab676ae8e9f2cfda2fd845f5b1/static/js/remoteEntry.js"

      
    