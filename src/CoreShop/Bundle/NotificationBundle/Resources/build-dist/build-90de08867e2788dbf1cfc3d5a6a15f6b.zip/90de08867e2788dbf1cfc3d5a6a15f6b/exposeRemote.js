
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopnotification = "/bundles/coreshopnotification/studio/90de08867e2788dbf1cfc3d5a6a15f6b/static/js/remoteEntry.js"

      
    