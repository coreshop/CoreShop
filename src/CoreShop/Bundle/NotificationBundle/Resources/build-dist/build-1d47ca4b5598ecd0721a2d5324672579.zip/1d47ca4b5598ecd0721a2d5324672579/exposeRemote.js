
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopnotification = "/bundles/coreshopnotification/studio/1d47ca4b5598ecd0721a2d5324672579/static/js/remoteEntry.js"

      
    