
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmessenger = "/bundles/coreshopmessenger/studio/0b41b9e2ae39f2a267b8e2a01d3b9f2e/static/js/remoteEntry.js"

      
    