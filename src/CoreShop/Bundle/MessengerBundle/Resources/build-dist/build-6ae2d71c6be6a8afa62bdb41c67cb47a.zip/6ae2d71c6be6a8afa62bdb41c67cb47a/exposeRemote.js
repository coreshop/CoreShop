
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmessenger = "/bundles/coreshopmessenger/studio/6ae2d71c6be6a8afa62bdb41c67cb47a/static/js/remoteEntry.js"

      
    