
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmessenger = "/bundles/coreshopmessenger/studio/e12f53794852eebde35689bfb5081c32/static/js/remoteEntry.js"

      
    