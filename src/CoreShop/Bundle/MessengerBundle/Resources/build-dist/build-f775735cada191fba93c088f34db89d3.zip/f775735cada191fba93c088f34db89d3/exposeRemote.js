
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmessenger = "/bundles/coreshopmessenger/studio/f775735cada191fba93c088f34db89d3/static/js/remoteEntry.js"

      
    