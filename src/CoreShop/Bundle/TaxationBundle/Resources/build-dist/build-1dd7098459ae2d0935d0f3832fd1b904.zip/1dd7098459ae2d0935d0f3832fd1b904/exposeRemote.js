
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoptaxation = "/bundles/coreshoptaxation/studio/1dd7098459ae2d0935d0f3832fd1b904/static/js/remoteEntry.js"

      
    