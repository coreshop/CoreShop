
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoptaxation = "/bundles/coreshoptaxation/studio/0c37aade0b173d4d7147cdf88c2a235f/static/js/remoteEntry.js"

      
    