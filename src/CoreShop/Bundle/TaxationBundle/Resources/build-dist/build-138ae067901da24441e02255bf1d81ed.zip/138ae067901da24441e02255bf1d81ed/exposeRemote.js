
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoptaxation = "/bundles/coreshoptaxation/studio/138ae067901da24441e02255bf1d81ed/static/js/remoteEntry.js"

      
    