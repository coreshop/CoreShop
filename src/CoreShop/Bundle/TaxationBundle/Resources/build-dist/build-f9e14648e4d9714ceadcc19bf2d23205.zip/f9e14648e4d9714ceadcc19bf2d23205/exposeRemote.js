
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoptaxation = "/bundles/coreshoptaxation/studio/f9e14648e4d9714ceadcc19bf2d23205/static/js/remoteEntry.js"

      
    