
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopvariant = "/bundles/coreshopvariant/studio/39b1ab28caec36ce4cb11dd76612d376/static/js/remoteEntry.js"

      
    