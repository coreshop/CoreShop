
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopvariant = "/bundles/coreshopvariant/studio/cd5074a94fbd1afdba84d12d483bd175/static/js/remoteEntry.js"

      
    