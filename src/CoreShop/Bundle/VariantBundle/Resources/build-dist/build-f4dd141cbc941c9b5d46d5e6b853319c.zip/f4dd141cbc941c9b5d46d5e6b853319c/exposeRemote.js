
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopvariant = "/bundles/coreshopvariant/studio/f4dd141cbc941c9b5d46d5e6b853319c/static/js/remoteEntry.js"

      
    