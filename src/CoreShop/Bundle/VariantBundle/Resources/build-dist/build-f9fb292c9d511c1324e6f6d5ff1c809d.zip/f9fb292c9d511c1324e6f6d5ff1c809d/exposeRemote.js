
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopvariant = "/bundles/coreshopvariant/studio/f9fb292c9d511c1324e6f6d5ff1c809d/static/js/remoteEntry.js"

      
    