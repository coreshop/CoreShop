
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopuser = "/bundles/coreshopuser/studio/6bb3f52780974b6c5483d68bafec4777/static/js/remoteEntry.js"

      
    