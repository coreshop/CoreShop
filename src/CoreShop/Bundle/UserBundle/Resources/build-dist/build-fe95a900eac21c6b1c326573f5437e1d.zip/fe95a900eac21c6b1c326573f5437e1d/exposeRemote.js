
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopuser = "/bundles/coreshopuser/studio/fe95a900eac21c6b1c326573f5437e1d/static/js/remoteEntry.js"

      
    