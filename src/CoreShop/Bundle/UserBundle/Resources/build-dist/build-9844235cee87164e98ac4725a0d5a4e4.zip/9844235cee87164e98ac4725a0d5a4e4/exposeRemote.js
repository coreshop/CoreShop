
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopuser = "/bundles/coreshopuser/studio/9844235cee87164e98ac4725a0d5a4e4/static/js/remoteEntry.js"

      
    