
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopuser = "/bundles/coreshopuser/studio/1409e3f03c24c67c4e1c7dc57f3eea03/static/js/remoteEntry.js"

      
    