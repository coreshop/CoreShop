
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcustomer = "/bundles/coreshopcustomer/studio/64da8433a9ddb19f249810a5e1f9d3ac/static/js/remoteEntry.js"

      
    