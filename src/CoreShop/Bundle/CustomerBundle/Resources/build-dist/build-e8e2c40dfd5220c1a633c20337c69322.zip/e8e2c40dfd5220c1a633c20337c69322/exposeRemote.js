
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcustomer = "/bundles/coreshopcustomer/studio/e8e2c40dfd5220c1a633c20337c69322/static/js/remoteEntry.js"

      
    