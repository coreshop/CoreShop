
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcustomer = "/bundles/coreshopcustomer/studio/e40127fd26e67ac3dda90514aae74798/static/js/remoteEntry.js"

      
    