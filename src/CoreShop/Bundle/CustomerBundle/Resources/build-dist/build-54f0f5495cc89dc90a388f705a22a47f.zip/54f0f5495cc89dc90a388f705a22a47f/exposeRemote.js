
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcustomer = "/bundles/coreshopcustomer/studio/54f0f5495cc89dc90a388f705a22a47f/static/js/remoteEntry.js"

      
    