
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproduct = "/bundles/coreshopproduct/studio/b35e00c6096b2ac23100316fb788668f/static/js/remoteEntry.js"

      
    