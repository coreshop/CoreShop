
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproduct = "/bundles/coreshopproduct/studio/bac212dbbbbe690193cd37c8a481fa79/static/js/remoteEntry.js"

      
    