
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproduct = "/bundles/coreshopproduct/studio/c9725659e55561e9193f905ae7f2c534/static/js/remoteEntry.js"

      
    