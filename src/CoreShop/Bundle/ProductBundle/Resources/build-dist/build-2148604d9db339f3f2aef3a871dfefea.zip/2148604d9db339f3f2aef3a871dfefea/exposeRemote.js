
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproduct = "/bundles/coreshopproduct/studio/2148604d9db339f3f2aef3a871dfefea/static/js/remoteEntry.js"

      
    