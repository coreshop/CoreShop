
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproduct = "/bundles/coreshopproduct/studio/99994fa9dd7533e4198f5ae66ac8d8f0/static/js/remoteEntry.js"

      
    