
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstudioform = "/bundles/coreshopstudioform/studio/191b9d3031dbeb7c67458846ccb95272/static/js/remoteEntry.js"

      
    