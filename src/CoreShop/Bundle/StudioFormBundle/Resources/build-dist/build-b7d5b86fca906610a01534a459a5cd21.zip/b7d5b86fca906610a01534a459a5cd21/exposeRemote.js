
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstudioform = "/bundles/coreshopstudioform/studio/b7d5b86fca906610a01534a459a5cd21/static/js/remoteEntry.js"

      
    