
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstudioform = "/bundles/coreshopstudioform/studio/8203a950ed667fa39102392c4cc541f5/static/js/remoteEntry.js"

      
    