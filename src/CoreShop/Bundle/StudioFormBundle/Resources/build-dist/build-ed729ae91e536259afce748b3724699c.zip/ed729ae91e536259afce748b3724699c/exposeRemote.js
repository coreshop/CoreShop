
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstudioform = "/bundles/coreshopstudioform/studio/ed729ae91e536259afce748b3724699c/static/js/remoteEntry.js"

      
    