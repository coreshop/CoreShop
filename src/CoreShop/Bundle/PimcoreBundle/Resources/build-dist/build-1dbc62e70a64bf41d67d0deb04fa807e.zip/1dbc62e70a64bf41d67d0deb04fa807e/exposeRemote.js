
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppimcore = "/bundles/coreshoppimcore/studio/1dbc62e70a64bf41d67d0deb04fa807e/static/js/remoteEntry.js"

      
    