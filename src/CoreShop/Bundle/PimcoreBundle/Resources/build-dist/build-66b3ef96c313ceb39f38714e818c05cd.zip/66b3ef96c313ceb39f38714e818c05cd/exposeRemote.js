
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppimcore = "/bundles/coreshoppimcore/studio/66b3ef96c313ceb39f38714e818c05cd/static/js/remoteEntry.js"

      
    