
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppimcore = "/bundles/coreshoppimcore/studio/7cd28995e4ab6d6c82fd95a0956fb62a/static/js/remoteEntry.js"

      
    