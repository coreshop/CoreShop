
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppimcore = "/bundles/coreshoppimcore/studio/befcaffb7d930634dab4d304c1895a79/static/js/remoteEntry.js"

      
    