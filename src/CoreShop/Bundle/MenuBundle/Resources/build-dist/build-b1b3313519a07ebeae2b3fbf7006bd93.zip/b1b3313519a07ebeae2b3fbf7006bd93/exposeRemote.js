
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmenu = "/bundles/coreshopmenu/studio/b1b3313519a07ebeae2b3fbf7006bd93/static/js/remoteEntry.js"

      
    