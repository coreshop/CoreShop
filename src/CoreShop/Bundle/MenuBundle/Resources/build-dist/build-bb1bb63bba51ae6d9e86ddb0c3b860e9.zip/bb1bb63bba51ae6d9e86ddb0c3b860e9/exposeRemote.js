
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmenu = "/bundles/coreshopmenu/studio/bb1bb63bba51ae6d9e86ddb0c3b860e9/static/js/remoteEntry.js"

      
    