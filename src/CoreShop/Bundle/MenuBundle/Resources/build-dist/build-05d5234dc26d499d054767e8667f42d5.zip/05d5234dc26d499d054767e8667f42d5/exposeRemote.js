
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmenu = "/bundles/coreshopmenu/studio/05d5234dc26d499d054767e8667f42d5/static/js/remoteEntry.js"

      
    