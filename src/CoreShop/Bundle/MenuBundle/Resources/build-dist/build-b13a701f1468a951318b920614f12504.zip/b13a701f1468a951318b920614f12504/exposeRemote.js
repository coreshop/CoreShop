
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmenu = "/bundles/coreshopmenu/studio/b13a701f1468a951318b920614f12504/static/js/remoteEntry.js"

      
    