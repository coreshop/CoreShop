
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstore = "/bundles/coreshopstore/studio/f440b6138eb41ab2c40aa4e71c3b021d/static/js/remoteEntry.js"

      
    