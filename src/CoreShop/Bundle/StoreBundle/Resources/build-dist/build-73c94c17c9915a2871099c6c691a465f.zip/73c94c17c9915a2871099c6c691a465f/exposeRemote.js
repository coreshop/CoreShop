
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstore = "/bundles/coreshopstore/studio/73c94c17c9915a2871099c6c691a465f/static/js/remoteEntry.js"

      
    