
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstore = "/bundles/coreshopstore/studio/c793e4eca43046319151bb1e70f3cc50/static/js/remoteEntry.js"

      
    