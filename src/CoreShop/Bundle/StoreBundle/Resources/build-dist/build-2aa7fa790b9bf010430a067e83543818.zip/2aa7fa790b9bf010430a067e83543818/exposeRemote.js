
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopstore = "/bundles/coreshopstore/studio/2aa7fa790b9bf010430a067e83543818/static/js/remoteEntry.js"

      
    