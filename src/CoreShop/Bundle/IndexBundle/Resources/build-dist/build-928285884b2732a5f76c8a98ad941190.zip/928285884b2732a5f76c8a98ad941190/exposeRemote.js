
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopindex = "/bundles/coreshopindex/studio/928285884b2732a5f76c8a98ad941190/static/js/remoteEntry.js"

      
    