
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopindex = "/bundles/coreshopindex/studio/4c9c557b61fb6225f48d4599b1d7973d/static/js/remoteEntry.js"

      
    