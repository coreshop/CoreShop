
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopindex = "/bundles/coreshopindex/studio/0e661e223b1f4a6d0ac1a38303112796/static/js/remoteEntry.js"

      
    