
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopindex = "/bundles/coreshopindex/studio/244894bb48473f883886d18f3b1709e9/static/js/remoteEntry.js"

      
    