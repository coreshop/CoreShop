
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopindex = "/bundles/coreshopindex/studio/3f18c368f9ab9b09bf4529021858143e/static/js/remoteEntry.js"

      
    