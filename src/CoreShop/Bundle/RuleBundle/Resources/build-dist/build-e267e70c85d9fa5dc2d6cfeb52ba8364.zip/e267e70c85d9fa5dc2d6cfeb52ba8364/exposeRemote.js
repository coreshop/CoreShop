
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoprule = "/bundles/coreshoprule/studio/e267e70c85d9fa5dc2d6cfeb52ba8364/static/js/remoteEntry.js"

      
    