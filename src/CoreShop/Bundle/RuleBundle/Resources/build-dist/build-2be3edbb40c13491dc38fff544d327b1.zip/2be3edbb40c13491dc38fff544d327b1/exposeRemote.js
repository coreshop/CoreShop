
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoprule = "/bundles/coreshoprule/studio/2be3edbb40c13491dc38fff544d327b1/static/js/remoteEntry.js"

      
    