
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoprule = "/bundles/coreshoprule/studio/4afacbd3d1e9d34b9e4c38ad64d68244/static/js/remoteEntry.js"

      
    