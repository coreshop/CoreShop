
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoprule = "/bundles/coreshoprule/studio/ceeda650d0bc8a7a1c51b9c747c91a35/static/js/remoteEntry.js"

      
    