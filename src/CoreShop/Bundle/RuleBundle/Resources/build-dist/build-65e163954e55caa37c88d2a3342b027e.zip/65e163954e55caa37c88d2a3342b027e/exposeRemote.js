
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoprule = "/bundles/coreshoprule/studio/65e163954e55caa37c88d2a3342b027e/static/js/remoteEntry.js"

      
    