
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmoney = "/bundles/coreshopmoney/studio/75e645b3b6b3d58fd499bb5fa72c952f/static/js/remoteEntry.js"

      
    