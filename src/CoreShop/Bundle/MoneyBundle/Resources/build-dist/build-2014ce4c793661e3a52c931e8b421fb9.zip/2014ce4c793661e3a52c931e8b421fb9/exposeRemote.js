
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmoney = "/bundles/coreshopmoney/studio/2014ce4c793661e3a52c931e8b421fb9/static/js/remoteEntry.js"

      
    