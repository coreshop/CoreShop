
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmoney = "/bundles/coreshopmoney/studio/288a6afe377182e40a38bbbac2b55940/static/js/remoteEntry.js"

      
    