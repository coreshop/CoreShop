
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopmoney = "/bundles/coreshopmoney/studio/36c75f741cfd1cae588744120cd385fd/static/js/remoteEntry.js"

      
    