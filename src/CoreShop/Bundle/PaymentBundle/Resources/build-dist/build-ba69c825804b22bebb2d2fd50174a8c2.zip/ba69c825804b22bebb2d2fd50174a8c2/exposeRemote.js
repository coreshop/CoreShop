
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppayment = "/bundles/coreshoppayment/studio/ba69c825804b22bebb2d2fd50174a8c2/static/js/remoteEntry.js"

      
    