
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppayment = "/bundles/coreshoppayment/studio/001fb56327d9e6e1a5d59db70c17cbb2/static/js/remoteEntry.js"

      
    