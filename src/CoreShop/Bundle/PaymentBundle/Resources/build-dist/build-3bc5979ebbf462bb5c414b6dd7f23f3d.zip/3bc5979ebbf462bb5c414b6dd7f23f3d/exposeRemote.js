
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppayment = "/bundles/coreshoppayment/studio/3bc5979ebbf462bb5c414b6dd7f23f3d/static/js/remoteEntry.js"

      
    