
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppayment = "/bundles/coreshoppayment/studio/240b200a919fd9bdbd9021d5efaf2d53/static/js/remoteEntry.js"

      
    