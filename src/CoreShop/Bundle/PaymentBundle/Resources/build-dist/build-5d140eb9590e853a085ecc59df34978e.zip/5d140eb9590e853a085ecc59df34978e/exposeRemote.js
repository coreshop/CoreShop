
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoppayment = "/bundles/coreshoppayment/studio/5d140eb9590e853a085ecc59df34978e/static/js/remoteEntry.js"

      
    