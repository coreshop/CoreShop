
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcore = "/bundles/coreshopcore/studio/7844f351f797bfc059c127d729ef227c/static/js/remoteEntry.js"

      
    