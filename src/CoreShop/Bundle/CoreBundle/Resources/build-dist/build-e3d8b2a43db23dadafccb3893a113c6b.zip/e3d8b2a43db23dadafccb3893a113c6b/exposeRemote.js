
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcore = "/bundles/coreshopcore/studio/e3d8b2a43db23dadafccb3893a113c6b/static/js/remoteEntry.js"

      
    