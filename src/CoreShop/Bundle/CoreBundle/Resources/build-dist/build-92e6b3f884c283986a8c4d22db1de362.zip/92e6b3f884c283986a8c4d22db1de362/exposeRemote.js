
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcore = "/bundles/coreshopcore/studio/92e6b3f884c283986a8c4d22db1de362/static/js/remoteEntry.js"

      
    