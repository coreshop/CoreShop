
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcore = "/bundles/coreshopcore/studio/627c4ac9f390c72948131d4cb6e09769/static/js/remoteEntry.js"

      
    