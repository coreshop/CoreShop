
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcore = "/bundles/coreshopcore/studio/9d4cac39666552465810121fd8675705/static/js/remoteEntry.js"

      
    