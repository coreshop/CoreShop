
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopresource = "/bundles/coreshopresource/studio/18be8bd2545107eb62b37a22673b3f99/static/js/remoteEntry.js"

      
    