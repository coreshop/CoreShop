
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopresource = "/bundles/coreshopresource/studio/d886254f4ef328e0fb65821f42c1fa3c/static/js/remoteEntry.js"

      
    