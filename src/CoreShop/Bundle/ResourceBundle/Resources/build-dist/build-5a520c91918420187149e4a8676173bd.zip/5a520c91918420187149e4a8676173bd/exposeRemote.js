
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopresource = "/bundles/coreshopresource/studio/5a520c91918420187149e4a8676173bd/static/js/remoteEntry.js"

      
    