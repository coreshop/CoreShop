
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopresource = "/bundles/coreshopresource/studio/286114ac89c7cb7e7111515ec76adb15/static/js/remoteEntry.js"

      
    