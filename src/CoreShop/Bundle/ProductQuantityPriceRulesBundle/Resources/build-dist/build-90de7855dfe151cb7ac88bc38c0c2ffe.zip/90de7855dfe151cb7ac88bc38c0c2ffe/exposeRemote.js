
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopproductquantitypricerules = "/bundles/coreshopproductquantitypricerules/studio/90de7855dfe151cb7ac88bc38c0c2ffe/static/js/remoteEntry.js"

      
    