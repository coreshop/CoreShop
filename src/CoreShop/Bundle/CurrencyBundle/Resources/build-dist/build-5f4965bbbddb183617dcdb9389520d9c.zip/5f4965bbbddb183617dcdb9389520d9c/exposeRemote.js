
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcurrency = "/bundles/coreshopcurrency/studio/5f4965bbbddb183617dcdb9389520d9c/static/js/remoteEntry.js"

      
    