
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcurrency = "/bundles/coreshopcurrency/studio/c5ee98fe562748d3cd228ee3d11dd5e0/static/js/remoteEntry.js"

      
    