
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcurrency = "/bundles/coreshopcurrency/studio/cee4c12104c58c1f13f9dd1f77d9fc47/static/js/remoteEntry.js"

      
    