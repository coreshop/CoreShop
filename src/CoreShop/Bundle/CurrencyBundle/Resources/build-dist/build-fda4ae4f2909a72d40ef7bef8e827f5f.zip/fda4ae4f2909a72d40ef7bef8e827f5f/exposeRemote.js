
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopcurrency = "/bundles/coreshopcurrency/studio/fda4ae4f2909a72d40ef7bef8e827f5f/static/js/remoteEntry.js"

      
    