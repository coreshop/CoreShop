
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopshipping = "/bundles/coreshopshipping/studio/b1f268a0d1cf1471a748664162121243/static/js/remoteEntry.js"

      
    