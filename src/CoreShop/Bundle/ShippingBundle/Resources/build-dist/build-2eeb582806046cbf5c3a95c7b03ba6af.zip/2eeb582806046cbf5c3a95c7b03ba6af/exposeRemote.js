
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopshipping = "/bundles/coreshopshipping/studio/2eeb582806046cbf5c3a95c7b03ba6af/static/js/remoteEntry.js"

      
    