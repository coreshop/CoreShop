
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopshipping = "/bundles/coreshopshipping/studio/a63f064281056e704f4170efe594510e/static/js/remoteEntry.js"

      
    