
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopshipping = "/bundles/coreshopshipping/studio/999870695d31794b1219e13e6f9b2732/static/js/remoteEntry.js"

      
    