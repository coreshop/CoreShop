
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopshipping = "/bundles/coreshopshipping/studio/e63a728d4985fab06d9e8798034ada6a/static/js/remoteEntry.js"

      
    