
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopaddress = "/bundles/coreshopaddress/studio/c13656438760e32d45f8c01da0b54b57/static/js/remoteEntry.js"

      
    