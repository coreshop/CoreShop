
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopaddress = "/bundles/coreshopaddress/studio/526b0f20454c33fac69815946fef2274/static/js/remoteEntry.js"

      
    