
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopaddress = "/bundles/coreshopaddress/studio/94e8553c74733bf6679e715451839e43/static/js/remoteEntry.js"

      
    