
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshopaddress = "/bundles/coreshopaddress/studio/bfdfb27fa72b85a6e75b057f9bb0e75f/static/js/remoteEntry.js"

      
    