
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoporder = "/bundles/coreshoporder/studio/8ae1c80e7a734712cb0880b0a11774c2/static/js/remoteEntry.js"

      
    