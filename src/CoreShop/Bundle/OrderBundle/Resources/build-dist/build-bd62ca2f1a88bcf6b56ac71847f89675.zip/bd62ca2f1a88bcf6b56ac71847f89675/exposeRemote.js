
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoporder = "/bundles/coreshoporder/studio/bd62ca2f1a88bcf6b56ac71847f89675/static/js/remoteEntry.js"

      
    