
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoporder = "/bundles/coreshoporder/studio/021810be0c64e8b2bb4263add7fee9f3/static/js/remoteEntry.js"

      
    