
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoporder = "/bundles/coreshoporder/studio/9bb2b22498d62a413e3616b034768953/static/js/remoteEntry.js"

      
    