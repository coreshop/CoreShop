
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.coreshoporder = "/bundles/coreshoporder/studio/e073e70ff7ae925b70db0b6864a620ad/static/js/remoteEntry.js"

      
    